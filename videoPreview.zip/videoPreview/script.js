console.log("page loaded...");

function hoverover(element) {
    element.play()
}

function hoverout(element) {
    element.pause()
}