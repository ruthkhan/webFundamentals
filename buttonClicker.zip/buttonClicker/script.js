function logout(clickspot) {
    clickspot.innerText = "Logout"
}

function addDefn(clickspot) {
    clickspot.remove()
}

function liked() {
    alert('Ninja was liked')
}